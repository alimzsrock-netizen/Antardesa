/* AntarDesa v0.3.0 G1 - shared UI messages. No network or transaction actions. */
(function (global) {
  'use strict';
  const messages = Object.freeze({
    'UI-01': 'Sedang memuat data…',
    'UI-02': 'Belum ada produk yang tersedia.',
    'UI-03': 'Belum ada riwayat pesanan.',
    'UI-04': 'Belum ada penugasan yang dapat ditampilkan.',
    'UI-05': 'Koneksi internet terputus. Periksa jaringan dan coba lagi.',
    'UI-06': 'Data belum dapat dimuat. Silakan coba lagi.',
    'UI-07': 'Sesi Anda berakhir. Silakan login kembali.',
    'UI-08': 'Anda tidak memiliki akses ke halaman ini.',
    'UI-09': 'Sebagian informasi belum tersedia.',
    'UI-10': 'Estimasi ini bukan pesanan dan tidak menjamin ketersediaan stok.',
    'UI-11': 'Masa berlaku estimasi hampir berakhir.',
    'UI-12': 'Estimasi telah kedaluwarsa. Perbarui estimasi untuk melihat informasi terbaru.',
    'UI-13': 'Checkout belum tersedia.',
    'UI-14': 'Periksa kembali data yang dimasukkan.',
    'UI-15': 'Periksa email Anda untuk melanjutkan konfirmasi akun.',
    'UI-16': 'Permintaan verifikasi sedang ditinjau.'
  });
  const kinds = Object.freeze({
    'UI-01': 'loading', 'UI-02': 'empty', 'UI-03': 'empty', 'UI-04': 'empty',
    'UI-05': 'warning', 'UI-06': 'error', 'UI-07': 'warning', 'UI-08': 'error',
    'UI-09': 'warning', 'UI-10': 'info', 'UI-11': 'warning', 'UI-12': 'warning',
    'UI-13': 'info', 'UI-14': 'error', 'UI-15': 'info', 'UI-16': 'info'
  });
  function get(id) {
    return Object.prototype.hasOwnProperty.call(messages, id) ? messages[id] : null;
  }
  function render(target, id) {
    const element = typeof target === 'string' ? document.querySelector(target) : target;
    const message = get(id);
    if (!element || !message) return false;
    element.replaceChildren();
    const notice = document.createElement('div');
    notice.className = 'ad-ui-notice ad-ui-notice--' + kinds[id];
    notice.dataset.uiMessage = id;
    notice.setAttribute('role', kinds[id] === 'error' ? 'alert' : 'status');
    const label = document.createElement('span');
    label.className = 'ad-ui-notice__text';
    label.textContent = message;
    notice.appendChild(label);
    element.appendChild(notice);
    return true;
  }
  global.AntarDesaUI = Object.freeze({ messages, get, render });
})(window);
